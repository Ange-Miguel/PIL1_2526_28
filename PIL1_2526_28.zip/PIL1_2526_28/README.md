# PIL1_2526_28 — IFRI_MentorLink

Projet intégrateur L1 IFRI - UAC 2025-2026  
Application web de mentorat académique entre étudiants de l'IFRI.

## Stack technique
- **Backend** : Django + Django REST Framework + MySQL
- **Frontend** : HTML / CSS / JavaScript (Bootstrap)
- **Auth** : JWT (SimpleJWT)
- **Temps réel** : Django Channels + Redis

## Lancement rapide

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env   # configurer les variables
python manage.py migrate
python manage.py runserver
```

Importer la base de données :
```bash
mysql -u root -p ifri_mentorlink < FICHIER_SQL_PIL1_2526_28.sql
```

## Membres du groupe 28
(à compléter)
