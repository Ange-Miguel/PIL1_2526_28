from django.apps import AppConfig

class competencesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.competences"
