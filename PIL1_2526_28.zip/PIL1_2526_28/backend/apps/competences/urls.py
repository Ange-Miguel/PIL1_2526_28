from django.urls import path
from .views import (
    MatiereListView,
    CompetenceListCreateView, CompetenceDeleteView,
    LacuneListCreateView, LacuneDeleteView,
)

urlpatterns = [
    path("matieres/",       MatiereListView.as_view()),
    path("",                CompetenceListCreateView.as_view()),
    path("<int:pk>/",       CompetenceDeleteView.as_view()),
    path("lacunes/",        LacuneListCreateView.as_view()),
    path("lacunes/<int:pk>/", LacuneDeleteView.as_view()),
]
