from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Matiere, CompetenceUtilisateur, LacuneUtilisateur
from .serializers import MatiereSerializer, CompetenceSerializer, LacuneSerializer


class MatiereListView(generics.ListAPIView):
    """GET /api/competences/matieres/"""
    queryset           = Matiere.objects.all()
    serializer_class   = MatiereSerializer
    permission_classes = [IsAuthenticated]


class CompetenceListCreateView(generics.ListCreateAPIView):
    """GET / POST /api/competences/"""
    serializer_class   = CompetenceSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return CompetenceUtilisateur.objects.filter(utilisateur=self.request.user)

    def perform_create(self, serializer):
        serializer.save(utilisateur=self.request.user)


class CompetenceDeleteView(generics.DestroyAPIView):
    """DELETE /api/competences/<pk>/"""
    serializer_class   = CompetenceSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return CompetenceUtilisateur.objects.filter(utilisateur=self.request.user)


class LacuneListCreateView(generics.ListCreateAPIView):
    """GET / POST /api/competences/lacunes/"""
    serializer_class   = LacuneSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return LacuneUtilisateur.objects.filter(utilisateur=self.request.user)

    def perform_create(self, serializer):
        serializer.save(utilisateur=self.request.user)


class LacuneDeleteView(generics.DestroyAPIView):
    """DELETE /api/competences/lacunes/<pk>/"""
    serializer_class   = LacuneSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return LacuneUtilisateur.objects.filter(utilisateur=self.request.user)
