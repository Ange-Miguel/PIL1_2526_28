from django.db import models
from apps.accounts.models import Utilisateur


class Matiere(models.Model):
    nom       = models.CharField(max_length=150)
    categorie = models.CharField(max_length=80, null=True, blank=True)
    description = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "matiere"

    def __str__(self):
        return self.nom


class CompetenceUtilisateur(models.Model):
    NIVEAUX = [(i, str(i)) for i in range(1, 6)]
    utilisateur     = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name="competences")
    matiere         = models.ForeignKey(Matiere, on_delete=models.CASCADE)
    niveau_maitrise = models.PositiveSmallIntegerField(default=3, choices=NIVEAUX)

    class Meta:
        db_table        = "competence_utilisateur"
        unique_together = ("utilisateur", "matiere")


class LacuneUtilisateur(models.Model):
    PRIORITES = [(1,"Faible"), (2,"Moyenne"), (3,"Élevée")]
    utilisateur     = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name="lacunes")
    matiere         = models.ForeignKey(Matiere, on_delete=models.CASCADE)
    priorite        = models.PositiveSmallIntegerField(default=2, choices=PRIORITES)
    date_creation   = models.DateTimeField(auto_now_add=True)
    date_resolution = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table        = "lacune_utilisateur"
        unique_together = ("utilisateur", "matiere")
