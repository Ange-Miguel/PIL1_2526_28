from rest_framework import serializers
from .models import Matiere, CompetenceUtilisateur, LacuneUtilisateur


class MatiereSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Matiere
        fields = ["id", "nom", "categorie"]


class CompetenceSerializer(serializers.ModelSerializer):
    matiere_nom = serializers.CharField(source="matiere.nom", read_only=True)

    class Meta:
        model  = CompetenceUtilisateur
        fields = ["id", "matiere", "matiere_nom", "niveau_maitrise"]


class LacuneSerializer(serializers.ModelSerializer):
    matiere_nom = serializers.CharField(source="matiere.nom", read_only=True)

    class Meta:
        model  = LacuneUtilisateur
        fields = ["id", "matiere", "matiere_nom", "priorite", "date_resolution"]
