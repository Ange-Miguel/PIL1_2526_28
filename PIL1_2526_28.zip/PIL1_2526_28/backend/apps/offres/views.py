from rest_framework import generics, filters, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import OffreMentorat
from .serializers import OffreSerializer


class OffreListCreateView(generics.ListCreateAPIView):
    """GET /api/offres/   POST /api/offres/"""
    serializer_class   = OffreSerializer
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter]
    search_fields      = ["matieres__nom", "type_offre", "format_session"]

    def get_queryset(self):
        qs = OffreMentorat.objects.filter(statut="active").select_related("auteur")
        type_offre = self.request.query_params.get("type")
        if type_offre:
            qs = qs.filter(type_offre=type_offre)
        return qs

    def perform_create(self, serializer):
        serializer.save(auteur=self.request.user)


class OffreDetailView(generics.RetrieveUpdateDestroyAPIView):
    """GET / PUT / DELETE /api/offres/<pk>/"""
    serializer_class   = OffreSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return OffreMentorat.objects.filter(auteur=self.request.user)

    def destroy(self, request, *args, **kwargs):
        offre = self.get_object()
        offre.statut = "annulee"
        offre.save()
        return Response({"message": "Offre annulée."}, status=status.HTTP_200_OK)
