from django.db import models
from apps.accounts.models import Utilisateur
from apps.competences.models import Matiere


class OffreMentorat(models.Model):
    TYPE_CHOICES   = [("offre","Offre"), ("demande","Demande")]
    FORMAT_CHOICES = [("presentiel","Présentiel"), ("en_ligne","En ligne"), ("les_deux","Les deux")]
    STATUT_CHOICES = [("active","Active"), ("pourvue","Pourvue"), ("annulee","Annulée")]

    auteur            = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name="offres")
    type_offre        = models.CharField(max_length=10, choices=TYPE_CHOICES)
    format_session    = models.CharField(max_length=15, choices=FORMAT_CHOICES, default="les_deux")
    description       = models.TextField(null=True, blank=True)
    statut            = models.CharField(max_length=10, choices=STATUT_CHOICES, default="active")
    matieres          = models.ManyToManyField(Matiere, through="OffreMatiere")
    date_creation     = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "offre_mentorat"

    def __str__(self):
        return f"{self.type_offre} — {self.auteur}"


class OffreMatiere(models.Model):
    offre   = models.ForeignKey(OffreMentorat, on_delete=models.CASCADE)
    matiere = models.ForeignKey(Matiere, on_delete=models.CASCADE)

    class Meta:
        db_table        = "offre_matiere"
        unique_together = ("offre", "matiere")


class OffreDisponibilite(models.Model):
    JOURS = [
        ("Lundi","Lundi"), ("Mardi","Mardi"), ("Mercredi","Mercredi"),
        ("Jeudi","Jeudi"), ("Vendredi","Vendredi"), ("Samedi","Samedi"), ("Dimanche","Dimanche"),
    ]
    offre        = models.ForeignKey(OffreMentorat, on_delete=models.CASCADE, related_name="disponibilites")
    jour_semaine = models.CharField(max_length=10, choices=JOURS)
    heure_debut  = models.TimeField()
    heure_fin    = models.TimeField()

    class Meta:
        db_table = "offre_disponibilite"
