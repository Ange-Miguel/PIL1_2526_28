from django.apps import AppConfig

class offresConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.offres"
