from django.urls import path
from .views import OffreListCreateView, OffreDetailView

urlpatterns = [
    path("",         OffreListCreateView.as_view()),
    path("<int:pk>/", OffreDetailView.as_view()),
]
