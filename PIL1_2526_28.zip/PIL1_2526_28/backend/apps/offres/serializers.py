from rest_framework import serializers
from .models import OffreMentorat, OffreMatiere, OffreDisponibilite
from apps.accounts.serializers import ProfilSerializer


class OffreDisponibiliteSerializer(serializers.ModelSerializer):
    class Meta:
        model  = OffreDisponibilite
        fields = ["id", "jour_semaine", "heure_debut", "heure_fin"]


class OffreSerializer(serializers.ModelSerializer):
    disponibilites = OffreDisponibiliteSerializer(many=True, read_only=True)
    auteur_detail  = ProfilSerializer(source="auteur", read_only=True)
    matieres_ids   = serializers.PrimaryKeyRelatedField(
        source="matieres", many=True, read_only=True
    )

    class Meta:
        model  = OffreMentorat
        fields = [
            "id", "auteur", "auteur_detail", "type_offre", "format_session",
            "description", "statut", "matieres_ids", "disponibilites",
            "date_creation", "date_modification",
        ]
        read_only_fields = ["auteur", "statut", "date_creation", "date_modification"]
