from rest_framework.permissions import BasePermission

class IsOwner(BasePermission):
    """Autorise uniquement le propriétaire de l'objet."""
    def has_object_permission(self, request, view, obj):
        return obj == request.user or obj.utilisateur == request.user
