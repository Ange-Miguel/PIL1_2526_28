from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models


class Filiere(models.Model):
    code        = models.CharField(max_length=20, unique=True)
    libelle     = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "filiere"

    def __str__(self):
        return self.code


class UtilisateurManager(BaseUserManager):
    def create_user(self, email, nom, prenom, telephone, password=None, **extra):
        if not email:
            raise ValueError("L'email est obligatoire")
        email = self.normalize_email(email)
        user  = self.model(email=email, nom=nom, prenom=prenom, telephone=telephone, **extra)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, nom, prenom, telephone, password=None, **extra):
        extra.setdefault("is_staff",     True)
        extra.setdefault("is_superuser", True)
        return self.create_user(email, nom, prenom, telephone, password, **extra)


class Utilisateur(AbstractBaseUser, PermissionsMixin):
    NIVEAU_CHOICES = [("L1","L1"),("L2","L2"),("L3","L3"),("M1","M1"),("M2","M2")]

    nom                = models.CharField(max_length=100)
    prenom             = models.CharField(max_length=100)
    email              = models.EmailField(unique=True)
    telephone          = models.CharField(max_length=20, unique=True)
    photo_profil       = models.CharField(max_length=500, null=True, blank=True)
    filiere            = models.ForeignKey(Filiere, on_delete=models.PROTECT, null=True)
    niveau             = models.CharField(max_length=2, choices=NIVEAU_CHOICES, default="L1")
    bio                = models.TextField(null=True, blank=True)
    est_actif          = models.BooleanField(default=True)
    date_inscription   = models.DateTimeField(auto_now_add=True)
    derniere_connexion = models.DateTimeField(null=True, blank=True)
    is_staff           = models.BooleanField(default=False)

    USERNAME_FIELD  = "email"
    REQUIRED_FIELDS = ["nom", "prenom", "telephone"]

    objects = UtilisateurManager()

    class Meta:
        db_table = "utilisateur"

    def __str__(self):
        return f"{self.prenom} {self.nom}"


class Disponibilite(models.Model):
    JOURS = [
        ("Lundi","Lundi"), ("Mardi","Mardi"), ("Mercredi","Mercredi"),
        ("Jeudi","Jeudi"), ("Vendredi","Vendredi"), ("Samedi","Samedi"), ("Dimanche","Dimanche"),
    ]
    utilisateur  = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name="disponibilites")
    jour_semaine = models.CharField(max_length=10, choices=JOURS)
    heure_debut  = models.TimeField()
    heure_fin    = models.TimeField()

    class Meta:
        db_table = "disponibilite"


class ResetPassword(models.Model):
    utilisateur     = models.ForeignKey(Utilisateur, on_delete=models.CASCADE)
    token           = models.CharField(max_length=255, unique=True)
    date_expiration = models.DateTimeField()
    utilise         = models.BooleanField(default=False)

    class Meta:
        db_table = "reset_password"
