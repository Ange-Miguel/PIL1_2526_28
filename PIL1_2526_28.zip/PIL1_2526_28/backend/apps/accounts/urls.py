from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    RegisterView, LoginView, ProfilView,
    ResetPasswordRequestView, ResetPasswordConfirmView,
)

urlpatterns = [
    path("register/",                RegisterView.as_view()),
    path("login/",                   LoginView.as_view()),
    path("token/refresh/",           TokenRefreshView.as_view()),
    path("profil/",                  ProfilView.as_view()),
    path("reset-password/request/",  ResetPasswordRequestView.as_view()),
    path("reset-password/confirm/",  ResetPasswordConfirmView.as_view()),
]
