from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from django.utils import timezone
import secrets

from .models import Utilisateur, ResetPassword
from .serializers import RegisterSerializer, ProfilSerializer


class RegisterView(generics.CreateAPIView):
    """POST /api/auth/register/"""
    queryset         = Utilisateur.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user    = serializer.save()
        refresh = RefreshToken.for_user(user)
        return Response({
            "message": "Compte créé avec succès.",
            "access":  str(refresh.access_token),
            "refresh": str(refresh),
        }, status=status.HTTP_201_CREATED)


class LoginView(APIView):
    """POST /api/auth/login/"""
    permission_classes = [AllowAny]

    def post(self, request):
        email    = request.data.get("email")
        password = request.data.get("password")
        user     = authenticate(request, username=email, password=password)
        if not user:
            return Response({"error": "Identifiants invalides."}, status=status.HTTP_401_UNAUTHORIZED)
        user.derniere_connexion = timezone.now()
        user.save(update_fields=["derniere_connexion"])
        refresh = RefreshToken.for_user(user)
        return Response({
            "access":  str(refresh.access_token),
            "refresh": str(refresh),
            "user":    ProfilSerializer(user).data,
        })


class ProfilView(generics.RetrieveUpdateAPIView):
    """GET / PUT /api/auth/profil/"""
    serializer_class   = ProfilSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user


class ResetPasswordRequestView(APIView):
    """POST /api/auth/reset-password/request/"""
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get("email")
        try:
            user  = Utilisateur.objects.get(email=email)
            token = secrets.token_urlsafe(32)
            from datetime import timedelta
            ResetPassword.objects.create(
                utilisateur=user,
                token=token,
                date_expiration=timezone.now() + timedelta(hours=1),
            )
            # En production : envoyer le token par email
            return Response({"message": "Token de réinitialisation généré.", "token": token})
        except Utilisateur.DoesNotExist:
            return Response({"error": "Email introuvable."}, status=status.HTTP_404_NOT_FOUND)


class ResetPasswordConfirmView(APIView):
    """POST /api/auth/reset-password/confirm/"""
    permission_classes = [AllowAny]

    def post(self, request):
        token       = request.data.get("token")
        new_password = request.data.get("password")
        try:
            reset = ResetPassword.objects.get(token=token, utilise=False)
            if reset.date_expiration < timezone.now():
                return Response({"error": "Token expiré."}, status=status.HTTP_400_BAD_REQUEST)
            reset.utilisateur.set_password(new_password)
            reset.utilisateur.save()
            reset.utilise = True
            reset.save()
            return Response({"message": "Mot de passe réinitialisé avec succès."})
        except ResetPassword.DoesNotExist:
            return Response({"error": "Token invalide."}, status=status.HTTP_400_BAD_REQUEST)
