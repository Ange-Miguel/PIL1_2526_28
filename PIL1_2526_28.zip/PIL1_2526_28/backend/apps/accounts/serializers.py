from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from .models import Utilisateur, Filiere, Disponibilite


class FiliereSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Filiere
        fields = ["id", "code", "libelle"]


class DisponibiliteSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Disponibilite
        fields = ["id", "jour_semaine", "heure_debut", "heure_fin"]


class RegisterSerializer(serializers.ModelSerializer):
    password  = serializers.CharField(write_only=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True)

    class Meta:
        model  = Utilisateur
        fields = ["nom", "prenom", "email", "telephone", "filiere", "niveau", "password", "password2"]

    def validate(self, data):
        if data["password"] != data["password2"]:
            raise serializers.ValidationError({"password": "Les mots de passe ne correspondent pas."})
        return data

    def create(self, validated_data):
        validated_data.pop("password2")
        password = validated_data.pop("password")
        user     = Utilisateur(**validated_data)
        user.set_password(password)
        user.save()
        return user


class ProfilSerializer(serializers.ModelSerializer):
    disponibilites = DisponibiliteSerializer(many=True, read_only=True)
    filiere_detail = FiliereSerializer(source="filiere", read_only=True)

    class Meta:
        model  = Utilisateur
        fields = [
            "id", "nom", "prenom", "email", "telephone",
            "photo_profil", "filiere", "filiere_detail",
            "niveau", "bio", "date_inscription", "disponibilites",
        ]
        read_only_fields = ["email", "date_inscription"]
