from django.urls import path
from .views import NotificationListView, NotificationLireView, NotificationLireToutesView

urlpatterns = [
    path("",                    NotificationListView.as_view()),
    path("<int:pk>/lire/",      NotificationLireView.as_view()),
    path("lire-toutes/",        NotificationLireToutesView.as_view()),
]
