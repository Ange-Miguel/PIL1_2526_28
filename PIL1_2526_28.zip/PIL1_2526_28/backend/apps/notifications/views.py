from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Notification
from .serializers import NotificationSerializer


class NotificationListView(generics.ListAPIView):
    """GET /api/notifications/"""
    serializer_class   = NotificationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Notification.objects.filter(destinataire=self.request.user)


class NotificationLireView(APIView):
    """PUT /api/notifications/<pk>/lire/"""
    permission_classes = [IsAuthenticated]

    def put(self, request, pk):
        try:
            notif = Notification.objects.get(pk=pk, destinataire=request.user)
            notif.est_lue = True
            notif.save()
            return Response(NotificationSerializer(notif).data)
        except Notification.DoesNotExist:
            return Response({"error": "Notification introuvable."}, status=status.HTTP_404_NOT_FOUND)


class NotificationLireToutesView(APIView):
    """PUT /api/notifications/lire-toutes/"""
    permission_classes = [IsAuthenticated]

    def put(self, request):
        Notification.objects.filter(destinataire=request.user, est_lue=False).update(est_lue=True)
        return Response({"message": "Toutes les notifications marquées comme lues."})
