from django.db import models
from apps.accounts.models import Utilisateur


class Notification(models.Model):
    TYPE_CHOICES = [
        ("nouveau_match",   "Nouveau match"),
        ("offre_acceptee",  "Offre acceptée"),
        ("nouveau_message", "Nouveau message"),
        ("match_accepte",   "Match accepté"),
    ]
    destinataire  = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name="notifications")
    type_notif    = models.CharField(max_length=30, choices=TYPE_CHOICES)
    contenu       = models.TextField()
    est_lue       = models.BooleanField(default=False)
    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "notification"
        ordering = ["-date_creation"]

    def __str__(self):
        return f"[{self.type_notif}] → {self.destinataire}"
