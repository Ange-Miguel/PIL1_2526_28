from django.apps import AppConfig

class messagerieConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.messagerie"
