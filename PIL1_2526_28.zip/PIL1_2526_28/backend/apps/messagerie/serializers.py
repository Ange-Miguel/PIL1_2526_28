from rest_framework import serializers
from .models import Conversation, Message


class MessageSerializer(serializers.ModelSerializer):
    expediteur_nom = serializers.CharField(source="expediteur.prenom", read_only=True)

    class Meta:
        model  = Message
        fields = ["id", "expediteur", "expediteur_nom", "contenu", "est_lu", "date_envoi"]
        read_only_fields = ["expediteur", "est_lu", "date_envoi"]


class ConversationSerializer(serializers.ModelSerializer):
    dernier_message = serializers.SerializerMethodField()

    class Meta:
        model  = Conversation
        fields = ["id", "id_participant1", "id_participant2", "date_dernier_msg", "dernier_message"]

    def get_dernier_message(self, obj):
        msg = obj.messages.last()
        return MessageSerializer(msg).data if msg else None
