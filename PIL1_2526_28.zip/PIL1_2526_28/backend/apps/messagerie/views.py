from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Q
from django.utils import timezone
from .models import Conversation, Message
from .serializers import ConversationSerializer, MessageSerializer


class ConversationListView(generics.ListAPIView):
    """GET /api/conversations/"""
    serializer_class   = ConversationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        uid = self.request.user.id
        return Conversation.objects.filter(
            Q(id_participant1=uid) | Q(id_participant2=uid)
        ).order_by("-date_dernier_msg")


class MessageListCreateView(generics.ListCreateAPIView):
    """GET / POST /api/conversations/<pk>/messages/"""
    serializer_class   = MessageSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        uid  = self.request.user.id
        conv = Conversation.objects.filter(
            pk=self.kwargs["pk"]
        ).filter(Q(id_participant1=uid) | Q(id_participant2=uid)).first()
        if not conv:
            return Message.objects.none()
        # Marquer les messages comme lus
        conv.messages.exclude(expediteur=self.request.user).update(est_lu=True)
        return conv.messages.all()

    def perform_create(self, serializer):
        uid  = self.request.user.id
        conv = Conversation.objects.filter(
            pk=self.kwargs["pk"]
        ).filter(Q(id_participant1=uid) | Q(id_participant2=uid)).first()
        if not conv:
            return Response({"error": "Conversation introuvable."}, status=status.HTTP_404_NOT_FOUND)
        msg = serializer.save(expediteur=self.request.user, conversation=conv)
        conv.date_dernier_msg = timezone.now()
        conv.save()
        # Notification temps réel via Channels
        from channels.layers import get_channel_layer
        from asgiref.sync import async_to_sync
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f"conv_{conv.id}",
            {"type": "chat_message", "message": MessageSerializer(msg).data}
        )
