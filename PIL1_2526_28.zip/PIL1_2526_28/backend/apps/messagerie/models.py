from django.db import models
from apps.accounts.models import Utilisateur


class Conversation(models.Model):
    id_participant1   = models.IntegerField()
    id_participant2   = models.IntegerField()
    date_dernier_msg  = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table        = "conversation"
        unique_together = ("id_participant1", "id_participant2")

    def get_other_participant(self, user_id):
        return self.id_participant2 if self.id_participant1 == user_id else self.id_participant1


class Message(models.Model):
    conversation  = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name="messages")
    expediteur    = models.ForeignKey(Utilisateur, on_delete=models.CASCADE)
    contenu       = models.TextField()
    est_lu        = models.BooleanField(default=False)
    date_envoi    = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table  = "message"
        ordering  = ["date_envoi"]
