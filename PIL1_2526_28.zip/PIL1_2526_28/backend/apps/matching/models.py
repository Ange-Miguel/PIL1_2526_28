from django.db import models
from apps.accounts.models import Utilisateur


class MatchMentorat(models.Model):
    STATUT_CHOICES = [
        ("propose","Proposé"), ("accepte","Accepté"),
        ("rejete","Rejeté"),   ("termine","Terminé"),
    ]

    mentor      = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name="matchs_mentor")
    mentore     = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name="matchs_mentore")
    score_total       = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    score_competences = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    score_horaires    = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    score_filiere     = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    score_niveau      = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    matieres_communes       = models.TextField(null=True, blank=True)
    disponibilites_communes = models.TextField(null=True, blank=True)
    statut        = models.CharField(max_length=10, choices=STATUT_CHOICES, default="propose")
    date_creation = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "match_mentorat"

    def __str__(self):
        return f"{self.mentor} → {self.mentore} ({self.score_total}%)"
