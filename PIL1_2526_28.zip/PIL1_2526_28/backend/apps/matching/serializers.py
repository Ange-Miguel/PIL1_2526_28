from rest_framework import serializers
from .models import MatchMentorat
from apps.accounts.serializers import ProfilSerializer


class MatchSerializer(serializers.ModelSerializer):
    mentor_detail  = ProfilSerializer(source="mentor",  read_only=True)
    mentore_detail = ProfilSerializer(source="mentore", read_only=True)

    class Meta:
        model  = MatchMentorat
        fields = [
            "id", "mentor", "mentor_detail", "mentore", "mentore_detail",
            "score_total", "score_competences", "score_horaires",
            "score_filiere", "score_niveau",
            "matieres_communes", "disponibilites_communes",
            "statut", "date_creation",
        ]
        read_only_fields = ["score_total", "score_competences", "score_horaires",
                            "score_filiere", "score_niveau", "date_creation"]
