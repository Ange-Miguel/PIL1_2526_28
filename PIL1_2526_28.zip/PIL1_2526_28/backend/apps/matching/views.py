from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Q
from .models import MatchMentorat
from .serializers import MatchSerializer
from .services import calculer_matchings


class MatchListView(generics.ListAPIView):
    """GET /api/matching/ — matchs de l'utilisateur connecté"""
    serializer_class   = MatchSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        return MatchMentorat.objects.filter(
            Q(mentor=user) | Q(mentore=user)
        ).order_by("-score_total")


class LancerMatchingView(APIView):
    """POST /api/matching/calculer/ — déclenche l'algorithme"""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        matchs = calculer_matchings(request.user)
        return Response({
            "message": f"{len(matchs)} match(s) calculé(s).",
            "matchs":  MatchSerializer(matchs, many=True).data,
        })


class MatchActionView(APIView):
    """POST /api/matching/<pk>/accepter/   POST /api/matching/<pk>/rejeter/"""
    permission_classes = [IsAuthenticated]

    def post(self, request, pk, action):
        try:
            match = MatchMentorat.objects.get(pk=pk, mentore=request.user)
        except MatchMentorat.DoesNotExist:
            return Response({"error": "Match introuvable."}, status=status.HTTP_404_NOT_FOUND)

        if action == "accepter":
            match.statut = "accepte"
            # Créer une conversation automatiquement
            from apps.messagerie.models import Conversation
            Conversation.objects.get_or_create(
                id_participant1=min(match.mentor.id, match.mentore.id),
                id_participant2=max(match.mentor.id, match.mentore.id),
            )
        elif action == "rejeter":
            match.statut = "rejete"

        match.save()
        return Response(MatchSerializer(match).data)
