"""
Algorithme de matching IFRI_MentorLink
Pondération :
  - Compétences / matières  : 45 %
  - Horaires                : 35 %
  - Filière                 : 10 %
  - Niveau d'études         : 10 %
"""
from apps.accounts.models import Utilisateur
from apps.competences.models import CompetenceUtilisateur, LacuneUtilisateur
from .models import MatchMentorat


NIVEAUX_ORDRE = {"L1": 1, "L2": 2, "L3": 3, "M1": 4, "M2": 5}


def _score_competences(mentor: Utilisateur, mentore: Utilisateur) -> tuple[float, list]:
    """Intersection entre compétences du mentor et lacunes du mentoré."""
    comp_ids  = set(CompetenceUtilisateur.objects.filter(utilisateur=mentor)
                    .values_list("matiere_id", flat=True))
    lacune_ids = set(LacuneUtilisateur.objects.filter(utilisateur=mentore)
                     .values_list("matiere_id", flat=True))
    communes  = comp_ids & lacune_ids
    if not lacune_ids:
        return 0.0, []
    score = min(45.0, (len(communes) / len(lacune_ids)) * 45)
    noms  = list(CompetenceUtilisateur.objects.filter(
        utilisateur=mentor, matiere_id__in=communes
    ).values_list("matiere__nom", flat=True))
    return round(score, 2), noms


def _score_horaires(mentor: Utilisateur, mentore: Utilisateur) -> tuple[float, list]:
    """Chevauchement en minutes entre les créneaux des deux utilisateurs."""
    from apps.accounts.models import Disponibilite
    from datetime import datetime

    def to_minutes(t):
        return t.hour * 60 + t.minute

    mentor_dispos  = mentor.disponibilites.all()
    mentore_dispos = mentore.disponibilites.all()

    total_overlap = 0
    slots         = []

    for d1 in mentor_dispos:
        for d2 in mentore_dispos:
            if d1.jour_semaine != d2.jour_semaine:
                continue
            debut = max(to_minutes(d1.heure_debut), to_minutes(d2.heure_debut))
            fin   = min(to_minutes(d1.heure_fin),   to_minutes(d2.heure_fin))
            if fin > debut:
                total_overlap += (fin - debut)
                slots.append(f"{d1.jour_semaine} {d1.heure_debut.strftime('%Hh')}-{d2.heure_fin.strftime('%Hh')}")

    score = min(35.0, (total_overlap / 120) * 35)  # 120 min = score plein
    return round(score, 2), slots


def _score_filiere(mentor: Utilisateur, mentore: Utilisateur) -> float:
    if mentor.filiere_id == mentore.filiere_id:
        return 10.0
    return 5.0  # filières différentes mais IFRI = points partiels


def _score_niveau(mentor: Utilisateur, mentore: Utilisateur) -> float:
    n1 = NIVEAUX_ORDRE.get(mentor.niveau,  1)
    n2 = NIVEAUX_ORDRE.get(mentore.niveau, 1)
    ecart = abs(n1 - n2)
    if ecart == 0:   return 10.0
    if ecart == 1:   return 7.0
    if ecart == 2:   return 4.0
    return 1.0


def calculer_matchings(utilisateur: Utilisateur):
    """Calcule et sauvegarde les matchs pour un utilisateur donné."""
    candidats = Utilisateur.objects.exclude(id=utilisateur.id).select_related("filiere")
    resultats = []

    for candidat in candidats:
        sc, matieres = _score_competences(candidat, utilisateur)
        sh, slots    = _score_horaires(candidat, utilisateur)
        sf           = _score_filiere(candidat, utilisateur)
        sn           = _score_niveau(candidat, utilisateur)
        total        = sc + sh + sf + sn

        if total < 20:  # seuil minimum
            continue

        match, _ = MatchMentorat.objects.update_or_create(
            mentor=candidat, mentore=utilisateur,
            defaults={
                "score_total":             total,
                "score_competences":       sc,
                "score_horaires":          sh,
                "score_filiere":           sf,
                "score_niveau":            sn,
                "matieres_communes":       ", ".join(matieres),
                "disponibilites_communes": ", ".join(slots),
                "statut":                  "propose",
            }
        )
        resultats.append(match)

    return sorted(resultats, key=lambda m: m.score_total, reverse=True)
