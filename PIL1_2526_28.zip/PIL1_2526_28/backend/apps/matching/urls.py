from django.urls import path
from .views import MatchListView, LancerMatchingView, MatchActionView

urlpatterns = [
    path("",                         MatchListView.as_view()),
    path("calculer/",                LancerMatchingView.as_view()),
    path("<int:pk>/<str:action>/",   MatchActionView.as_view()),
]
