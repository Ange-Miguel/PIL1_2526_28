from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/",                    admin.site.urls),
    path("api/auth/",                 include("apps.accounts.urls")),
    path("api/competences/",          include("apps.competences.urls")),
    path("api/offres/",               include("apps.offres.urls")),
    path("api/matching/",             include("apps.matching.urls")),
    path("api/conversations/",        include("apps.messagerie.urls")),
    path("api/notifications/",        include("apps.notifications.urls")),
]
